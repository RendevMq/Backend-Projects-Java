package com.example.presentation.controller;

import com.example.presentation.dto.WeatherDTO;
import com.example.service.interfaces.IWeatherService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

public class WeatherController {

    @Autowired
    private IWeatherService iWeatherService;

    @GetMapping("/weather/{city}")
    public WeatherDTO getWeatherByCity(@PathVariable String city) {
        return iWeatherService.getWeather(city);
    }

}
