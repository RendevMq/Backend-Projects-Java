package com.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Beg09WeatherApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(Beg09WeatherApiApplication.class, args);
	}

}
